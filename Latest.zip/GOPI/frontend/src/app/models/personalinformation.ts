export class PersonalInformation {
  Name: string;
  Email: string;
  Mobile: string;
  Address: string;
  GST: string;
  Logo: File;
  Company: String;
  Landline:String;
  Website:string;
  AccountNumber:string;
  Branchname:string;
  Bankname:string;
  Ifsc:string;
}
