export class InvoicFilter {
  Name: string;
  FromDate: string;
  ToDate: string;
  VehicleNumber: string;
  Model: string;
}
