import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-settins',
  templateUrl: './customer-settins.component.html',
  styleUrls: ['./customer-settins.component.sass']
})
export class CustomerSettinsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
