import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-base',
  templateUrl: './settings-base.component.html',
  styleUrls: ['./settings-base.component.sass']
})
export class SettingsBaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
