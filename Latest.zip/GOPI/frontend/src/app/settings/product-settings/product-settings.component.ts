import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-settings',
  templateUrl: './product-settings.component.html',
  styleUrls: ['./product-settings.component.sass']
})
export class ProductSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
