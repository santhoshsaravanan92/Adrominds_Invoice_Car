export class CustomerInformation {
  Name: string;
  Email: string;
  Mobile: string;
  Address: string;
  GST: string;
  Comments: string;
  OwnerEmail: string;
  Id:string;
}
