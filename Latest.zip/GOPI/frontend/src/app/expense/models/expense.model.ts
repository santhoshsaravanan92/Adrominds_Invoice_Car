export class ExpenseInformation {
    dated: string;
    price: number;
    category: string;
    notes: string;
    email: string;
    id:number;
}
